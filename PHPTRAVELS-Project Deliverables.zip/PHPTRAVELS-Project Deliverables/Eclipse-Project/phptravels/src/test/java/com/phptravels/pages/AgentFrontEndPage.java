package com.phptravels.pages;

import java.time.Duration;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.Locatable;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.phptravels.utilities.ExcelUtilities;

public class AgentFrontEndPage {
	
	WebDriver driver;
	
	@FindBy(id="ACCOUNT")
	WebElement account_btn;
	
	@FindBy(linkText="Customer Login")
	WebElement customer_Login;
	
	@FindBy(name="email")
	WebElement email_id;
	
	@FindBy(name="password")
	WebElement passwd;
	
	@FindBy(xpath="//span[text()='Login']")
	WebElement login_btn;
	
	@FindBy(linkText="My Bookings")
	WebElement my_Bookings;
	
	@FindBy(linkText="Add Funds")
	WebElement add_Funds;
	
	@FindBy(linkText="My Profile")
	WebElement my_Profile;
	
	@FindBy(linkText="Logout")
	WebElement logOut;
	
	
	@FindBy(xpath="//button[text()='Pay Now ']")
	WebElement pay_btn;

	
	@FindBy(id="download")
	WebElement download_Invoice_btn;
	
	@FindBy(name="address1")
	WebElement address;
	
	@FindBy(xpath="//button[text()='Update Profile']")
	WebElement update_profile;
	
	@FindBy(css="span[title=' Search by City']")
	WebElement citynam;
	
	@FindBy(css="input[role='searchbox']")
	WebElement cityname;
	
	@FindBy(css="li[role='option']")
	WebElement city;
	
	@FindBy(id="submit")
	WebElement search;
	
	@FindBy(linkText="Hotels")
	WebElement hotel;
	
	@FindBy(css="a[title='visa']")
	WebElement visa;
	
	@FindBy(css="a[title='flights']")
	WebElement flights;
	
	@FindBy(id="currency")
	WebElement currency;
	
	@FindBy(linkText="INR")
	WebElement currencyto;
	
	@FindBy(linkText="Tours")
	WebElement tours;
	
	@FindBy(linkText="Offers")
	WebElement offers;
	
	@FindBy(linkText="Blog")
	WebElement blog;
	
	@FindBy(linkText="Home")
	WebElement home;
	
	public AgentFrontEndPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	
	public void setEmail(String email) {
		email_id.sendKeys(email);
		
	}

	public void setPassword(String password) {
		passwd.sendKeys(password);
		
	}

	public void clickLoginButton() {
		login_btn.click();
		
	}

	public boolean isValidLogin() {
		return logOut.isDisplayed();
		
	}

	public boolean isInvalidLogin() {
		
		String url= driver.getCurrentUrl();
		if (url.equals("https://phptravels.net/login/failed"))
			{
				return true;
			}
		else 
			{
				return false;
		
			}
		 
	}

	public boolean isBlankLoginInvalid() {
		return login_btn.isDisplayed();
		 
	}

	public void click_My_Bookings() {
		
		my_Bookings.click();
	}

	public boolean is_Bookings_link_Valid() throws InterruptedException {
		String actual=driver.getCurrentUrl();
		String expected="https://phptravels.net/account/bookings";
		return actual.equals(expected);
		
	}

	public void click_Add_Funds() {
		add_Funds.click();
		
	}

	public boolean is_Add_Funds_link_Valid() throws InterruptedException {
		 WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(2000));
			wait.until(ExpectedConditions.visibilityOf(pay_btn));
		    
			return pay_btn.isDisplayed();
			
		
	}

	public void click_My_Profile() {
		
		my_Profile.click();
	}

	public boolean is_My_Profile_link_Valid() {
		try { ((Locatable) update_profile).getCoordinates().inViewPort();
		update_profile.click();
	        }
	       catch(Exception e)
	       {
	        new Actions(driver).sendKeys(Keys.PAGE_DOWN).perform();
	        WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(2000));
			wait.until(ExpectedConditions.visibilityOf(update_profile));
	        
	       }
		return  update_profile.isDisplayed();
		
	}

	public void click_Logout() {
		logOut.click();
		
	}

	public boolean is_Logout_link_Valid() {
		
		    WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(2000));
			wait.until(ExpectedConditions.visibilityOf(login_btn));
			return login_btn.isDisplayed();
		
	}


	
	



	public void click_Currency() {
		currency.click();
		
	}


	public boolean is_currency_Convert_Valid(String curr) {
		String cur=currency.getText();
		
		return cur.equals(curr);
	}


	public void set_Currency() {
		currencyto.click();
		
	}

	public void click_Offers() {
		offers.click();
		
	}


	public boolean is_Offers_link_Valid() {
	    
		return driver.getPageSource().contains("PHPTRAVELS Offers");
	}


	public void click_Blog() {
		blog.click();
		
	}

	public boolean is_Blog_link_Valid() {
		
			return driver.getPageSource().contains("PHPTRAVELS Blog");
		
	}

	public void click_Home() {
		home.click();
		
	}

	public boolean is_Home_link_Valid() {
		
			return driver.getCurrentUrl().equals("https://phptravels.net/");
		
	}

	public boolean is_Search_Hotel_Valid(String city2) throws InterruptedException {
		
		boolean actual=driver.getPageSource().contains("Search Hotels in "+city2.toLowerCase());
		driver.navigate().to("https://phptravels.net/login");
		return actual;
	}


	public void click_Search() throws InterruptedException {
		//Thread.sleep(1000);
		search.click();
		
	}


	public void setCity(String city2) throws InterruptedException {
		
		
		citynam.click();
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(2000));
		wait.until(ExpectedConditions.elementToBeClickable(cityname));
		Thread.sleep(500);
		cityname.sendKeys(city2);
		WebDriverWait wait2=new WebDriverWait(driver,Duration.ofSeconds(2000));
		wait2.until(ExpectedConditions.elementToBeClickable(city));
		Thread.sleep(5000);
		city.click();
		Thread.sleep(1000);
		
	}


	public boolean is_Visa_link_Valid() {
		
		return driver.getPageSource().contains("Submit Your Visa Today!");
	}

	public void click_Visa() {
		visa.click();
		
	}

	public boolean is_Tours_link_Valid() {
		
		return driver.getPageSource().contains("FIND BEST TOURS PACKAGES TODAY");
	}
	public void click_Tours() {
		tours.click();
		
	}

	public void click_Flights() {
		flights.click();
		
	}

	public boolean is_Flights_link_Valid() {
		
		return driver.getPageSource().contains("SEARCH FOR BEST FLIGHTS");
	}


	public boolean is_Hotels_link_Valid() {
		hotel.click();
		return driver.getPageSource().contains("SEARCH FOR BEST HOTELS");
	}


	public boolean isBlankLogin() {
		
		return login_btn.isDisplayed();
	}


	public void click_Hotels() {
		hotel.click();
		
	}




	
	


}
