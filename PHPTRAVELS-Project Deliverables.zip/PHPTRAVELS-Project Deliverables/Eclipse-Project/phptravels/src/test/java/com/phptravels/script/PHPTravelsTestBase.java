package com.phptravels.script;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.phptravels.pages.CustomerFrontEndPage;

import io.github.bonigarcia.wdm.WebDriverManager;
public class PHPTravelsTestBase
{	
	WebDriver driver;
	static Properties prop;
	public static void PHPTravelsTestBase() throws IOException 
	{
		String cpath=System.getProperty("user.dir")+"/src/test/resources/config.properties";
		prop=new Properties();
		FileInputStream fis=new FileInputStream(cpath);
		prop.load(fis);
		
	}
	@BeforeTest
	public void onSetUp() throws IOException 
	{
		PHPTravelsTestBase();
		String browser=prop.getProperty("browser");
		String url=prop.getProperty("url");
		if(browser.equals("chrome"))
		{
			WebDriverManager.chromedriver().setup();
			driver=new ChromeDriver();
			
		}
		else if(browser.equals("edge"))
		{
			WebDriverManager.edgedriver().setup();
			driver=new EdgeDriver();
			
		}
		else if(browser.equals("firefox"))
		{
			WebDriverManager.firefoxdriver().setup();
			driver=new FirefoxDriver();
			
		}
		
	}
	@BeforeTest
	public void set()
	{
		String url=prop.getProperty("supplierurl");//URL CHANGING AS PER EACH MODULE RUNNING
		driver.get(url);
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		
	}
//	@BeforeMethod
//	public void initbase()
//	{	  String url=prop.getProperty("url");
//	      driver.get(url);
//		
//	}
	
}
	
	

