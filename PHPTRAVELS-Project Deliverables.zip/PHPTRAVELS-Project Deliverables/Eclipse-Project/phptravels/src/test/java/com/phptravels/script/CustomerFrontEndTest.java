package com.phptravels.script;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.phptravels.pages.CustomerFrontEndPage;
import com.phptravels.utilities.ExcelUtilities;

public class CustomerFrontEndTest extends PHPTravelsTestBase {
	
	CustomerFrontEndPage cust_page;
	
	
	@BeforeTest
	public void init() throws IOException
	{	
		cust_page=new CustomerFrontEndPage(driver);	
		
		
	}
	@AfterTest
	public void close() 
	{  
		driver.quit();
	}
	
	public void login() throws IOException 
	{
		String email=ExcelUtilities.getcelldata("Customer_Data_Scenario", 3, 1);
		String password=ExcelUtilities.getcelldata("Customer_Data_Scenario", 4, 1);
//		cust_page.clickAccountButton();
//		cust_page.clickCustomerLoginLink();
		cust_page.setEmail(email);
		cust_page.setPassword(password);
		cust_page.clickLoginButton();
	
	}
	
	@Test
	//valid Login
	public void valid_Customer_Login() throws IOException 
	{
		String email=ExcelUtilities.getcelldata("Customer_Data_Scenario", 3, 1);
		String password=ExcelUtilities.getcelldata("Customer_Data_Scenario", 4, 1);
//		cust_page.clickAccountButton();
//		cust_page.clickCustomerLoginLink();
		cust_page.setEmail(email);
		cust_page.setPassword(password);
		cust_page.clickLoginButton();
		boolean actual=cust_page.isValidLogin();
		//logout();
		Assert.assertEquals(actual,true);
		
	}
	
	@Test(groups={"Cust_invalidLogin_Module"})
	//Invalid Login
	public void inValid_Customer_Login() throws IOException 
	{
		String email=ExcelUtilities.getcelldata("Customer_Data_Scenario", 7, 1);
		String password=ExcelUtilities.getcelldata("Customer_Data_Scenario",8, 1);
//		cust_page.clickAccountButton();
//		cust_page.clickCustomerLoginLink();
		cust_page.setEmail(email);
		cust_page.setPassword(password);
		cust_page.clickLoginButton();
		boolean actual=cust_page.isInvalidLogin();
		Assert.assertEquals(actual, true);
		
	}
	@Test
	//Invalid login ,Keep emailid/password field blank
	public void blank_Credentials_Customer_Login() throws IOException 
	{
		
//		cust_page.clickAccountButton();
//		cust_page.clickCustomerLoginLink();
		cust_page.clickLoginButton();
		boolean actual=cust_page.isBlankLoginInvalid();
		Assert.assertEquals(actual, true);
		
	}
	@Test
	//Check My Bookings link
	public void check_My_Bookings_Link() throws IOException, InterruptedException 
	{
		
		cust_page.click_My_Bookings();
		boolean actual=cust_page.is_Bookings_link_Valid();
		//logout();
		Assert.assertEquals(actual, true);
		
		
	}
	@Test
	//Check Add Funds link
	public void check_Add_Funds_Link() throws IOException, InterruptedException 
	{
		
		cust_page.click_Add_Funds();
		boolean actual=cust_page.is_Add_Funds_link_Valid();
		//logout();
		Assert.assertEquals(actual, true);
		
		
	}
	
	@Test
	//Check My Profile link
	public void check_My_Profile_Link() throws IOException, InterruptedException 
	{
		
		cust_page.click_My_Profile();
		boolean actual=cust_page.is_My_Profile_link_Valid();
		//logout();
		Assert.assertEquals(actual, true);
		
	}
	
	@Test
	//Check LogOut link
	public void check_Logout_Link() throws IOException, InterruptedException 
	{
		
		cust_page.click_Logout();
		boolean actual=cust_page.is_Logout_link_Valid();
		Assert.assertEquals(actual, true);
		
	}
	
	@Test
	//Pay Using PayPal
	public void pay_PayPal() throws IOException, InterruptedException 
	{
		
		try
		{
		cust_page.click_Add_Funds();
		String amount=ExcelUtilities.getcelldata("Customer_Data_Scenario",13, 1);
		cust_page.click_Pay_With_PayPal();
		cust_page.set_Amount(amount);
		cust_page.pay_btn_Click();
		cust_page.payPal_btn_Click();
		
		
		boolean actual=cust_page.is_PayPal_Valid();
		//logout();
		Assert.assertEquals(actual, true);
		}
		catch(Exception e)
		{   String url=prop.getProperty("url");
	        driver.get(url);
			Assert.assertFalse(true);
		}
		
		
		
	}
	
	@Test
	//Display of voucher
	public void displaying_Voucher() throws IOException, InterruptedException 
	{
		
		cust_page.click_My_Bookings();
		cust_page.click_View_Voucher_Btn();
		boolean actual=cust_page.is_Download_Invoice_Btn_Present();
		//logout();
		Assert.assertEquals(actual, true);
		
	}
	
	@Test
	//Change Address
	public void change_Address() throws IOException, InterruptedException 
	{
		
		cust_page.click_My_Profile();
		String address=ExcelUtilities.getcelldata("Customer_Data_Scenario",17, 1);
		cust_page.set_Address(address);
		cust_page.click_Update_profile_Btn();
		boolean actual=cust_page.is_Update_Success();
		//logout();
		Assert.assertEquals(actual, true);
		
	}
 
}
