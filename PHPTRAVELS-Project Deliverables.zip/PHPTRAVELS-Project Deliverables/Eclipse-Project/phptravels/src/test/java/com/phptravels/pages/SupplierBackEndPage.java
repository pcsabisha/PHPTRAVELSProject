package com.phptravels.pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SupplierBackEndPage {

    WebDriver driver;
    
    @FindBy(id="dropdownMenuProfile")
	WebElement account;
    
    @FindBy(name="email")
	WebElement email_id;
	
	@FindBy(name="password")
	WebElement passwd;
    
    @FindBy(xpath="//div[text()='Logout']")
	WebElement logOut;
   
	@FindBy(xpath="//span[text()='Login']")
	WebElement login_btn;
	
	@FindBy(xpath="//div[text()='Dashboard']")
	WebElement dashboard;	
		
	@FindBy(xpath="//div[text()='Sales overview & summary']")
	WebElement sales_overview;
	

	@FindBy(css="div[class='display-5']")
	List<WebElement> count;
	
	@FindBy(id="booking_status")
	WebElement booking_status;
	
	@FindBy(xpath="//div[text()='Pending Bookings']")
	WebElement pending_bookings;
	
	@FindBy(xpath="//i[text()='luggage']")
	WebElement tours;
	
	@FindBy(xpath="//i[text()='receipt']")
	WebElement bookings;
	
	int counts,pending,confirmed;
	
	public SupplierBackEndPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	public void clickLoginButton() {
		WebDriverWait wait2=new WebDriverWait(driver,Duration.ofSeconds(60));
		wait2.until(ExpectedConditions.visibilityOf(login_btn));
		login_btn.click();
		
	}

	public boolean isBlankLoginInvalid() {
		return login_btn.isDisplayed();
	}

	public void setPassword(String password) {
		passwd.clear();
		passwd.sendKeys(password);
		
	}

	public boolean isInvalidLogin() {
		return login_btn.isDisplayed();
	}

	public void setEmail(String email) {
		email_id.clear();
		email_id.sendKeys(email);
		
	}
	

	public boolean isValidLogin() {
		account.click();
		return logOut.isDisplayed();
	}




	public void click_Logout() {
		account.click();
		logOut.click();
		
	}

	public void click_Dashboard_Link() {
		dashboard.click();
		
	}

	public boolean is_Valid_Display_SalesOveriew() throws InterruptedException {
		WebDriverWait wait2=new WebDriverWait(driver,Duration.ofSeconds(2000));
		wait2.until(ExpectedConditions.visibilityOf(sales_overview));
		boolean actual=sales_overview.isDisplayed();
		return actual;
	}

	public boolean is_Valid_Display_RevenueBreakDown() {
		boolean actual=driver.getPageSource().contains("Revenue Breakdown");
		return actual;
	}
	

	public void click_Pending_Bookings() {
		confirmed=Integer.parseInt(count.get(0).getText());
		pending=Integer.parseInt(count.get(1).getText());
		pending_bookings.click();
		
	}

	public void change_Pending__To_Confirmed() throws InterruptedException {
		
		Select s=new Select(booking_status);
		s.selectByVisibleText("Confirmed");
		Thread.sleep(1000);
	}

	public boolean is_Valid_Pending_To_Confirmed() {
		dashboard.click();
		int changed_pending=Integer.parseInt(count.get(1).getText());
		int changed_confirmed=Integer.parseInt(count.get(0).getText());
		if((changed_pending==pending-1)&&(changed_confirmed==confirmed+1))
		{
		return true;
		}
		else
		{
		return false;
		}
	}

	public boolean is_Valid_Tours() {
		
		return tours.isDisplayed()&& tours.isEnabled();
	}

	public boolean is_Valid_Bookings_Link() {
		return bookings.isDisplayed()&& bookings.isEnabled();
	}


}
