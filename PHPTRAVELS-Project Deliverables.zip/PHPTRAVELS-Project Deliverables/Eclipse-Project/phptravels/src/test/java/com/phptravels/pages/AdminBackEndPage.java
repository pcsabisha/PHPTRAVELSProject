package com.phptravels.pages;

import java.time.Duration;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AdminBackEndPage  {
	WebDriver driver;

	@FindBy(name="email")
	WebElement email_id;
	
	@FindBy(name="password")
	WebElement passwd;
	
	@FindBy(xpath="//span[text()='Login']")
	WebElement login_btn;
	
	@FindBy(xpath="//div[text()='Logout']")
	WebElement logOut;
	
	@FindBy(id="dropdownMenuProfile")
	WebElement account;
	
	@FindBy(linkText="Bookings")
	WebElement bookings;
	
	@FindBy(xpath="//option[text()='paid']")
	WebElement paid_status;
	
	@FindBy(id="download")
	WebElement download_invoice;
	
	@FindBy(xpath="//*[@id=\"data\"]/tbody/tr")
	List<WebElement> rows;
	
	@FindBy(xpath="//*[@id=\"data\"]/tbody/tr[1]/td")
	List<WebElement> cols;
	
	@FindBy(xpath="//div[text()='Cancelled Bookings']")
	WebElement cancelled_bookings;
	
	@FindBy(xpath="//div[text()='Pending Bookings']")
	WebElement pending_bookings;
	
	@FindBy(xpath="//*[@id=\"data\"]/tbody/tr[1]/td[15]/button")
	WebElement delete;
	
	@FindBy(linkText="Website")
	WebElement website_link;
	
	@FindBy(css="div[class='display-5']")
	List<WebElement> count;
	
	@FindBy(id="booking_status")
	WebElement booking_status;
	
	int counts,pending,confirmed;
	
	public AdminBackEndPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	public void click_Logout() throws InterruptedException {
		account.click();
		Thread.sleep(100);
		logOut.click();
		
	}

	public void clickLoginButton() {
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(1500));
		wait.until(ExpectedConditions.visibilityOf(login_btn));
		login_btn.click();
		
	}

	public boolean isBlankLoginInvalid() {
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(1500));
		wait.until(ExpectedConditions.visibilityOf(login_btn));
		return login_btn.isDisplayed();
	}

	public void setPassword(String password) {
		passwd.clear();
		passwd.sendKeys(password);
		
	}

	public boolean isInvalidLogin() {
		return login_btn.isDisplayed();
	}

	public void setEmail(String email) {
		email_id.clear();
		email_id.sendKeys(email);
		
	}
	

	public boolean isValidLogin() {
		
		account.click();
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(1000));
		wait.until(ExpectedConditions.visibilityOf(logOut));
		return logOut.isDisplayed();
	}

	public void click_Bookings_Link() {
		bookings.click();
		
	}

	public boolean is_Valid_Bookings_Link() {
		
		return driver.getTitle().equals("All Bookings View");
	}

	public boolean is_Valid_Paid_Invoice_Dispaly() throws InterruptedException {
		 //String p=paid_status.getAttribute("value");
			//System.out.println(p);
			int j=12;
			int k=14;
			for(int i=1;i<=rows.size();i++)
			{
								
				WebElement pay_status=	driver.findElement(By.xpath("//*[@id='data']//tbody/tr["+i+"]/td["+j+"]/select"));
				WebElement invoice=	driver.findElement(By.xpath("//*[@id='data']//tbody/tr["+i+"]/td["+k+"]/a"));
				Select s=new Select(pay_status);
				
				
				if(s.getFirstSelectedOption().getText().equals("PAID"))
				{    
					invoice.click();
					break;
					//System.out.println(invoice.getText());
				}
							
			}
		Set<String> pages=	driver.getWindowHandles();
		String parent=driver.getWindowHandle();
		Iterator<String> it=pages.iterator();
		while(it.hasNext())
		{
			String child=it.next();
			driver.switchTo().window(child);
		}
		boolean actual= download_invoice.isDisplayed();
		Thread.sleep(500);
		driver.close();
		driver.switchTo().window(parent);
		driver.navigate().back();
		return actual;
		}

	
	public void click_Cancelled_Bookings() {
		cancelled_bookings.click();
		
	}

	public void click_Delete_Button() {
		 counts=Integer.parseInt(count.get(2).getText());
		 delete.click();
	}
	
	public boolean is_Valid_Delete_Cancelled_Booking() throws InterruptedException {
		
		
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		int cnt=Integer.parseInt(count.get(2).getText());
		if(cnt==counts-1)
		{
			return true;
		}
		else
		{
		return false;
		}
	}



	public void click_Website_Link() {
		website_link.click();
		
	}

	public boolean is_Website_Link_Valid() throws InterruptedException {
	    	Set<String> pages=driver.getWindowHandles();
		String parent=driver.getWindowHandle();
		Iterator<String> it=pages.iterator();
		boolean actual;
		while(it.hasNext())
		{
		driver.switchTo().window(it.next());
		}
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(1000));
		wait.until(ExpectedConditions.urlToBe("https://phptravels.net/"));
		System.out.println(driver.getCurrentUrl());
		if(driver.getCurrentUrl().equals("https://phptravels.net/"))
		{
		actual=true;
		}
		else
		{
			actual=false;
		}
		Thread.sleep(1000);
		driver.close();
		
		return actual;
	}

	public void click_Pending_Bookings() {
		pending_bookings.click();
		
	}

	public void change_Pending__To_Confirmed() throws InterruptedException {
		confirmed=Integer.parseInt(count.get(0).getText());
		pending=Integer.parseInt(count.get(1).getText());
		Select s=new Select(booking_status);
		s.selectByVisibleText("Confirmed");
		Thread.sleep(1000);
	}

	public boolean is_Valid_Pending_To_Confirmed() {
		int changed_pending=Integer.parseInt(count.get(1).getText());
		int changed_confirmed=Integer.parseInt(count.get(0).getText());
		if((changed_pending==pending-1)&&(changed_confirmed==confirmed+1))
		{
		return true;
		}
		else
		{
		return false;
		}
	}

		


}
