package com.phptravels.script;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.phptravels.pages.SupplierBackEndPage;
import com.phptravels.utilities.ExcelUtilities;

public class SupplierBackEndTest extends PHPTravelsTestBase {
	
			SupplierBackEndPage supplier_page;
			@BeforeTest
			public void init()
			{	
				supplier_page=new SupplierBackEndPage(driver);	
			}
			@AfterTest
			public void close() throws InterruptedException
			{  
				driver.quit();
			}
//			@AfterMethod
//			public void logOut() throws InterruptedException 
//			{  
//				logout();
//			}
			public void logout() 
			{
				supplier_page.click_Logout();
			}
			public void login() throws IOException
			{
			String email=ExcelUtilities.getcelldata("Supplier_Data_Scenario", 3, 1);
			String password=ExcelUtilities.getcelldata("Supplier_Data_Scenario", 4, 1);
			supplier_page.setEmail(email);
			supplier_page.setPassword(password);
			supplier_page.clickLoginButton();
			}
			
			@Test
			//valid Login
			public void valid_Supplier_Login() throws IOException 
			{
				String email=ExcelUtilities.getcelldata("Supplier_Data_Scenario", 3, 1);
				String password=ExcelUtilities.getcelldata("Supplier_Data_Scenario", 4, 1);
				supplier_page.setEmail(email);
				supplier_page.setPassword(password);
				supplier_page.clickLoginButton();
				boolean actual=supplier_page.isValidLogin();
				Assert.assertEquals(actual,true);
			
			}
			
			@Test
			//Invalid Login
			public void inValid_Supplier_Login() throws IOException 
			{
				String email=ExcelUtilities.getcelldata("Supplier_Data_Scenario", 7, 1);
				String password=ExcelUtilities.getcelldata("Supplier_Data_Scenario",8, 1);
				supplier_page.setEmail(email);
				supplier_page.setPassword(password);
				supplier_page.clickLoginButton();
				boolean actual=supplier_page.isInvalidLogin();
				Assert.assertEquals(actual, true);
				
			}
			
			@Test
			//Invalid login ,Keep emailid/password field blank
			public void blank_Credentials_Supplier_Login() throws IOException 
			{
				

				supplier_page.clickLoginButton();
				boolean actual=supplier_page.isBlankLoginInvalid();
				Assert.assertEquals(actual, true);
				
			}
			
			@Test
			//check display of 'Revenue Breakdown'
			public void check_Display_Of_Revenue_Breakdown() throws IOException, InterruptedException 
			{
				
				supplier_page.click_Dashboard_Link();
				boolean actual=supplier_page.is_Valid_Display_RevenueBreakDown();
				Assert.assertEquals(actual, true);
				
			}
			
			@Test
			//change Booking Status from Pending to Confirmed
			public void change_Pending_To_Confirmed() throws IOException, InterruptedException  
			{
			
				supplier_page.click_Pending_Bookings();
				supplier_page.change_Pending__To_Confirmed();
				boolean actual=supplier_page.is_Valid_Pending_To_Confirmed();
				Assert.assertEquals(actual, true);
				
			}
			
			@Test
			//check display of 'Sales Overview & summary'
			public void check_Display_Of_SalesOverviewandSummary() throws IOException, InterruptedException 
			{
				supplier_page.click_Dashboard_Link();
				boolean actual=supplier_page.is_Valid_Display_SalesOveriew();
				Assert.assertEquals(actual, true);
				
			}
			@Test
			//check whether Tours link is displayed and clickable'
			public void check_Display_And_Clickable_Of_Tours_Link() throws IOException, InterruptedException 
			{
				supplier_page.click_Dashboard_Link();
				boolean actual=supplier_page.is_Valid_Tours();
				Assert.assertEquals(actual, true);
				
			}
			
			@Test
			//check whether Bookings link is displayed and clickable'
			public void check_Display_And_Clickable_Of_Bookings_Link() throws IOException, InterruptedException 
			{
				supplier_page.click_Dashboard_Link();
				boolean actual=supplier_page.is_Valid_Bookings_Link();
				Assert.assertEquals(actual, true);
				
			}
		}



