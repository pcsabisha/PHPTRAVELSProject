package com.phptravels.utilities;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtilities {
	static XSSFWorkbook wbook;
	static XSSFSheet wsheet;
	public static String getcelldata(String sheetname,int row,int col) throws IOException
	{
		String fpath=System.getProperty("user.dir")+"\\src\\test\\resources\\Test_Data_phptravels.xlsx";
		FileInputStream f= new FileInputStream(fpath);
		wbook=new XSSFWorkbook(f);
		wsheet=wbook.getSheet(sheetname);
		return wsheet.getRow(row).getCell(col).toString();
		
	}	
	

}
