package com.phptravels.pages;

import java.time.Duration;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.Locatable;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.phptravels.utilities.ExcelUtilities;

public class CustomerFrontEndPage {
	
	WebDriver driver;
	
	@FindBy(id="ACCOUNT")
	WebElement account_btn;
	
	@FindBy(linkText="Customer Login")
	WebElement customer_Login;
	
	@FindBy(name="email")
	WebElement email_id;
	
	@FindBy(name="password")
	WebElement passwd;
	
	@FindBy(xpath="//span[text()='Login']")
	WebElement login_btn;
	
	@FindBy(linkText="My Bookings")
	WebElement my_Bookings;
	
	@FindBy(linkText="Add Funds")
	WebElement add_Funds;
	
	@FindBy(linkText="My Profile")
	WebElement my_Profile;
	
	@FindBy(linkText="Logout")
	WebElement logOut;
	
	@FindBy(id="gateway_paypal")
	WebElement pay_method;
	
	@FindBy(name="price")
	WebElement price;
	
	@FindBy(xpath="//button[text()='Pay Now ']")
	WebElement pay_btn;
	
	@FindBy(id="paypal-button")
	WebElement pay_pal_btn;
	
	@FindBy(linkText="View Voucher")
	WebElement view_Voucher_btn;
	
	@FindBy(id="download")
	WebElement download_Invoice_btn;
	
	@FindBy(name="address1")
	WebElement address;
	
	@FindBy(xpath="//button[text()='Update Profile']")
	WebElement update_profile;
	                 
	@FindBy(xpath="//div[text()=' Profile updated successfully.                                ']")
	WebElement update_success;	
	
	@FindBy(id="cookie_stop")
	WebElement cookie_stop;	

	
	public CustomerFrontEndPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	
	public void setEmail(String email) {
		email_id.clear();
		email_id.sendKeys(email);
		
	}

	public void setPassword(String password) {
		passwd.clear();
		passwd.sendKeys(password);
		
	}

	public void clickLoginButton() {
		login_btn.click();
		
	}

	public boolean isValidLogin() {
		return logOut.isDisplayed();
		
	}

	public boolean isInvalidLogin() {
		String url= driver.getCurrentUrl();
		if (url.equals("https://phptravels.net/login/failed"))
			{
				return true;
			}
		else 
			{
				return false;
		
			}
		 
	}

	public boolean isBlankLoginInvalid() {
		return login_btn.isDisplayed();
		 
	}

	public void click_My_Bookings() {
		
		my_Bookings.click();
	}

	public boolean is_Bookings_link_Valid() throws InterruptedException {
		boolean actual=view_Voucher_btn.isDisplayed();
		return actual;
		
	}

	public void click_Add_Funds() {
		add_Funds.click();
		
	}

	public boolean is_Add_Funds_link_Valid() throws InterruptedException {
		 WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(2000));
			wait.until(ExpectedConditions.visibilityOf(pay_btn));
		    
			return pay_btn.isDisplayed();
			
		
	}

	public void click_My_Profile() {
		
		my_Profile.click();
	}

	public boolean is_My_Profile_link_Valid() {
		try { ((Locatable) update_profile).getCoordinates().inViewPort();
		update_profile.click();
	        }
	       catch(Exception e)
	       {
	        new Actions(driver).sendKeys(Keys.PAGE_DOWN).perform();
	        WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(2000));
			wait.until(ExpectedConditions.visibilityOf(update_profile));
	        
	       }
		return  update_profile.isDisplayed();
		
	}

	public void click_Logout() {
		logOut.click();
		
	}

	public boolean is_Logout_link_Valid() {
		
		    WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(2000));
			wait.until(ExpectedConditions.visibilityOf(login_btn));
			return login_btn.isDisplayed();
		
	}


	public boolean is_PayPal_Valid() throws InterruptedException {
		
		
		String parent=driver.getWindowHandle();
		Set<String> childs=driver.getWindowHandles();
		Iterator<String> i=childs.iterator();
		String actualurl=null;
		String expected="Log in to your PayPal account";
		
		while(i.hasNext())
		{
			String child=i.next();
			
			if(!parent.equalsIgnoreCase(child))
			{
				driver.switchTo().window(child);
				driver.manage().window().maximize();
			}
						
		}
		
		WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.titleContains(expected));
		actualurl=driver.getTitle();
		driver.close();
		driver.switchTo().window(parent);
		
		
	
		
			driver.navigate().back();
			driver.navigate().back();
		
		return actualurl.equals(expected);
	}

	public void pay_btn_Click() throws InterruptedException {
		Thread.sleep(1000);
		pay_btn.click();
		
	}

	public void payPal_btn_Click() {
		
			pay_pal_btn.click();
		
	}

	
	public void click_Pay_With_PayPal() {
		pay_method.click();
		
	}

	public void set_Amount(String amount) {
		price.clear();
		price.sendKeys(amount);
		
	}

	public void click_View_Voucher_Btn() {
		view_Voucher_btn.click();
		
	}

	public boolean is_Download_Invoice_Btn_Present() {
		String parent=driver.getWindowHandle();
		Set<String> childs=driver.getWindowHandles();
		Iterator<String> i=childs.iterator();
		while(i.hasNext())
		{
			String child=i.next();
			if(!parent.equalsIgnoreCase(child))
			{
				driver.switchTo().window(child);
			}
		}
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(200));
		wait.until(ExpectedConditions.visibilityOf(download_Invoice_btn));
		//System.out.println(driver.getCurrentUrl());
		boolean actual= download_Invoice_btn.isDisplayed();
		driver.close();
		driver.switchTo().window(parent);
		return actual;
		
	}

	public void set_Address(String adrs) {
		address.clear();
		address.sendKeys(adrs);
		
	}

	public void click_Update_profile_Btn() throws InterruptedException {
		
	
		try { ((Locatable) cookie_stop).getCoordinates().inViewPort();
		cookie_stop.click();
	        }
	       catch(Exception e)
	       {
	        new Actions(driver).sendKeys(Keys.PAGE_DOWN).perform();
	        WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(2000));
			wait.until(ExpectedConditions.visibilityOf(cookie_stop));
			cookie_stop.click();
	       }
		
		try { ((Locatable) update_profile).getCoordinates().inViewPort();
		update_profile.click();
	        }
	       catch(Exception e)
	       {
	        new Actions(driver).sendKeys(Keys.PAGE_DOWN).perform();
	        WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(2000));
			wait.until(ExpectedConditions.visibilityOf(update_profile));
	        update_profile.click();
	       }
		
//		JavascriptExecutor js=(JavascriptExecutor) driver;
//		js.executeScript("arguments[0].scrollIntoView();", update_profile);
		
		
	}

	public boolean is_Update_Success() {
		
		
	    WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(2000));
		wait.until(ExpectedConditions.visibilityOf(update_profile));
		return update_success.isDisplayed();
	}

	
	
	

}
