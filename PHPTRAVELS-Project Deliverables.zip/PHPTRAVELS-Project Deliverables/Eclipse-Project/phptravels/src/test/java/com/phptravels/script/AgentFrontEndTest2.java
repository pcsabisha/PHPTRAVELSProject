package com.phptravels.script;

import static org.testng.Assert.fail;

import java.io.IOException;
import java.time.Duration;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.TestNG;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.phptravels.pages.AgentFrontEndPage;
import com.phptravels.pages.CustomerFrontEndPage;
import com.phptravels.utilities.ExcelUtilities;

public class AgentFrontEndTest2 extends PHPTravelsTestBase {
	AgentFrontEndPage agent_page;

	@BeforeTest
	public void init() throws IOException
	{	

		agent_page=new AgentFrontEndPage(driver);	
		
	}
	@AfterTest
	public void close() 
	{  
		driver.quit();
	}

	public void login() throws IOException
	{
	String email=ExcelUtilities.getcelldata("Agent_Data_Scenario", 3, 1);
	String password=ExcelUtilities.getcelldata("Agent_Data_Scenario", 4, 1);
	agent_page.setEmail(email);
	agent_page.setPassword(password);
	agent_page.clickLoginButton();
	}
	public void logout()
	{
		agent_page.click_Logout();
	}
	@Test(groups= {"logoutRequired"})
	//valid Login
	public void valid_Agent_Login() throws IOException 
	{  
		try
	{ 
		String email=ExcelUtilities.getcelldata("Agent_Data_Scenario", 3, 1);
		String password=ExcelUtilities.getcelldata("Agent_Data_Scenario", 4, 1);
		agent_page.setEmail(email);
		agent_page.setPassword(password);
		agent_page.clickLoginButton();
		
		boolean actual=agent_page.isValidLogin();
		Assert.assertEquals(actual,true);
	}
	catch(Exception e)
	{
		Assert.assertTrue(false);
	}
		
	}
	
	@Test
	//Invalid Login
	public void inValid_Agent_Login() throws IOException 
	{
		String email=ExcelUtilities.getcelldata("Agent_Data_Scenario", 7, 1);
		String password=ExcelUtilities.getcelldata("Agent_Data_Scenario",8, 1);

		agent_page.setEmail(email);
		agent_page.setPassword(password);
		agent_page.clickLoginButton();
		boolean actual=agent_page.isInvalidLogin();
		Assert.assertEquals(actual, true);
		
	}
	@Test
	//Invalid login ,Keep emailid/password field blank
	public void blank_Credentials_Agent_Login() throws IOException 
	{
		String email=null;
		String password=null;
		agent_page.clickLoginButton();
		boolean actual=agent_page.isBlankLogin();
		Assert.assertEquals(actual, true);
		
	}
	
	@Test(groups= {"logoutRequired"})
	//Check My Bookings link
	public void check_My_Bookings_Link() throws IOException, InterruptedException 
	{
		//login();
		agent_page.click_My_Bookings();
		boolean actual=agent_page.is_Bookings_link_Valid();
		Assert.assertEquals(actual, true);
		
	}
	
	@Test(groups= {"logoutRequired"})
	//Check Add Funds link
	public void check_Add_Funds_Link() throws IOException, InterruptedException 
	{
		//login();
		agent_page.click_Add_Funds();
		boolean actual=agent_page.is_Add_Funds_link_Valid();
		Assert.assertEquals(actual, true);
		
	}
	
	@Test(groups= {"logoutRequired"})
	//Check My Profile link
	public void check_My_Profile_Link() throws IOException, InterruptedException 
	{
		//login();
		agent_page.click_My_Profile();
		boolean actual=agent_page.is_My_Profile_link_Valid();
		
		Assert.assertEquals(actual, true);
	}
	
	@Test
	//Check LogOut link
	public void check_Logout_Link() throws IOException, InterruptedException 
	{
		//login();
		agent_page.click_Logout();
		boolean actual=agent_page.is_Logout_link_Valid();
		Assert.assertEquals(actual, true);
	}
  

	@Test(groups= {"logoutRequired"})
	//Check Home link
	public void check_Home_Link() throws IOException, InterruptedException 
	{
		agent_page.click_Home();
		boolean actual=agent_page.is_Home_link_Valid();
		Assert.assertEquals(actual, true);
		
	}

	@Test(groups= {"logoutRequired"})
	//Check Hotels link
	public void check_Hotels_Link() throws IOException, InterruptedException 
	{
		//login();
		boolean actual=agent_page.is_Hotels_link_Valid();
		
		Assert.assertEquals(actual, true);
		
	}
	
	@Test(groups= {"logoutRequired"})
	//Check Flights link
	public void check_Flighs_Link() throws InterruptedException, IOException  
	{
		agent_page.click_Flights();
		boolean actual=agent_page.is_Flights_link_Valid();
		Assert.assertEquals(actual, true);
		
	}
	
	@Test
	//Check Tours link
	public void check_Tours_Link() throws IOException, InterruptedException  
	{
		agent_page.click_Tours();
		boolean actual=agent_page.is_Tours_link_Valid();
		Assert.assertEquals(actual, true);
		
	}
	
	@Test
	//Check Visa link
	public void check_Visa_Link() throws IOException, Exception  
	{
		agent_page.click_Visa();
		boolean actual=agent_page.is_Visa_link_Valid();
		Assert.assertEquals(actual, true);
		
	}
	
	@Test
	//Search Hotel by City
	public void search_Hotel_By_City() throws IOException, InterruptedException  
	{
		
		String city=ExcelUtilities.getcelldata("Agent_Data_Scenario", 12, 0);
		//String city="Singapore";
		agent_page.click_Hotels();
		
		agent_page.setCity(city);
		agent_page.click_Search();
		boolean actual=agent_page.is_Search_Hotel_Valid(city);
		Assert.assertEquals(actual, true);
		
	}
	@Test
	//Check Blog link
	public void check_Blog_Link() throws IOException  
	{   
		agent_page.click_Blog();
		boolean actual=agent_page.is_Blog_link_Valid();
		Assert.assertEquals(actual, true);
		
	}
	
	@Test
	//Check Offers link
	public void check_Offers_Link() throws IOException  
	{
		agent_page.click_Offers();
		boolean actual=agent_page.is_Offers_link_Valid();
		Assert.assertEquals(actual, true);
		
	}
	@Test
	//Check Covert Currency 
	public void check_Convert_Currency() throws IOException   
	{
		agent_page.click_Currency();
		agent_page.set_Currency();
		boolean actual=agent_page.is_currency_Convert_Valid("INR");
		Assert.assertEquals(actual, true);
		
	}
	
	
}


