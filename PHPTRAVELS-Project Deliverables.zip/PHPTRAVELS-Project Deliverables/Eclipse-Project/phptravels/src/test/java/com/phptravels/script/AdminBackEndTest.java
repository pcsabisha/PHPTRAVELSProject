package com.phptravels.script;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.phptravels.pages.AdminBackEndPage;
import com.phptravels.utilities.ExcelUtilities;

public class AdminBackEndTest extends PHPTravelsTestBase {
	
AdminBackEndPage admin_page;
	

	@BeforeTest
	public void init()
	{

		admin_page=new AdminBackEndPage(driver);	
	}
	@AfterTest
	public void close() throws InterruptedException
	{  
		driver.quit();
	}
//	@AfterMethod(onlyForGroups= {"logoutRequired"})
//	public void logOut() throws InterruptedException
//	{  
//		logout();
//	}
	public void logout() throws InterruptedException 
	{
		admin_page.click_Logout();
	}
	public void login() throws IOException
	{
	String email=ExcelUtilities.getcelldata("Admin_Data_Scenario", 3, 1);
	String password=ExcelUtilities.getcelldata("Admin_Data_Scenario", 4, 1);
	admin_page.setEmail(email);
	admin_page.setPassword(password);
	admin_page.clickLoginButton();
	}
	
	@Test
	//valid Login
	public void valid_Admin_Login() throws IOException 
	{
		String email=ExcelUtilities.getcelldata("Admin_Data_Scenario", 3, 1);
		String password=ExcelUtilities.getcelldata("Admin_Data_Scenario", 4, 1);
		admin_page.setEmail(email);
		admin_page.setPassword(password);
		admin_page.clickLoginButton();
		boolean actual=admin_page.isValidLogin();
		Assert.assertEquals(actual,true);
		
	}
	
	@Test
	//Invalid Login
	public void inValid_Admin_Login() throws IOException 
	{
		String email=ExcelUtilities.getcelldata("Admin_Data_Scenario", 7, 1);
		String password=ExcelUtilities.getcelldata("Admin_Data_Scenario",8, 1);
		admin_page.setEmail(email);
		admin_page.setPassword(password);
		admin_page.clickLoginButton();
		boolean actual=admin_page.isInvalidLogin();
		Assert.assertEquals(actual, true);
		
	}
	
	@Test
	//Invalid login ,Keep emailid/password field blank
	public void blank_Credentials_Admin_Login() throws IOException 
	{
		

		admin_page.clickLoginButton();
		boolean actual=admin_page.isBlankLoginInvalid();
		Assert.assertEquals(actual, true);
		
	}
	
	@Test
	//Check Bookings link
	public void check_Admin_Bookings_Link() throws IOException 
	{
		admin_page.click_Bookings_Link();
		boolean actual=admin_page.is_Valid_Bookings_Link();
		Assert.assertEquals(actual, true);
		
	}
	
	@Test
	//Check display of Invoice of Successful payment
	public void display_Invoice_of_Payment_Successful() throws IOException, InterruptedException 
	{
		admin_page.click_Bookings_Link();
		boolean actual=admin_page.is_Valid_Paid_Invoice_Dispaly();
		Assert.assertEquals(actual, true);
		
	}
	
	@Test
	//Delete cancelled Booking
	public void delete_Cancelled_Booking() throws IOException, InterruptedException  
	{
		admin_page.click_Bookings_Link();
		admin_page.click_Cancelled_Bookings();
		admin_page.click_Delete_Button();
		boolean actual=admin_page.is_Valid_Delete_Cancelled_Booking();
		Assert.assertEquals(actual, true);
		
	}
	
	@Test
	//change Booking Status from Pending to Confirmed
	public void change_Pending_To_Confirmed() throws IOException, InterruptedException  
	{
		admin_page.click_Bookings_Link();
		admin_page.click_Pending_Bookings();
		admin_page.change_Pending__To_Confirmed();
		boolean actual=admin_page.is_Valid_Pending_To_Confirmed();
		Assert.assertEquals(actual, true);
		
	}
	
	
	
	@Test
	//check Website link
	public void check_Website_Link() throws IOException, InterruptedException  
	{
		admin_page.click_Website_Link();
		boolean actual=admin_page.is_Website_Link_Valid();
		Assert.assertEquals(actual, true);
		
	}
}
